package com.nova.assistant.intents

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.telecom.TelecomManager
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.nova.assistant.data.model.AssistantIntentAction

class IntentActionHandler(private val context: Context) {

    private val cameraManager by lazy {
        context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    }

    private var isTorchOn = false

    /**
     * Executes the requested intent action and returns an execution result status with message.
     */
    fun executeIntent(action: AssistantIntentAction): Pair<Boolean, String> {
        return when (action.type) {
            "OPEN_APP" -> {
                val appName = action.payload["appName"] ?: ""
                val launched = openApp(appName)
                if (launched) {
                    Pair(true, "জি তাপস স্যার, ${getDisplayName(appName)} খুলে দিচ্ছি।")
                } else {
                    Pair(false, "তাপস স্যার, ${getDisplayName(appName)} অ্যাপটি এই ডিভাইসে খুঁজে পাওয়া যায়নি।")
                }
            }
            "CALL_PHONE" -> {
                val phone = action.payload["phoneNumber"] ?: ""
                makeSafeCall(phone)
                Pair(true, "জি তাপস স্যার, কল ডায়ালার খোলা হচ্ছে।")
            }
            "ACCEPT_CALL" -> {
                acceptIncomingCall()
            }
            "END_CALL" -> {
                endOrRejectCall()
            }
            "SEND_SMS" -> {
                val recipient = action.payload["recipient"] ?: ""
                val message = action.payload["message"] ?: ""
                composeSms(recipient, message)
                Pair(true, "জি তাপস স্যার, মেসেজ প্রস্তুত করা হয়েছে।")
            }
            "NAVIGATE_MAPS" -> {
                val destination = action.payload["destination"] ?: "Dhaka"
                val success = startNavigation(destination)
                if (success) {
                    Pair(true, "জি তাপস স্যার, ${destination}-এর গুগল ম্যাপস নেভিগেশন চালু করা হচ্ছে।")
                } else {
                    Pair(false, "তাপস স্যার, গুগল ম্যাপস চালু করা সম্ভব হয়নি।")
                }
            }
            "TOGGLE_FLASHLIGHT" -> {
                val state = action.payload["state"]
                val (success, msg) = toggleFlashlight(state)
                Pair(success, msg)
            }
            "SEARCH_WEB" -> {
                val query = action.payload["query"] ?: ""
                searchWeb(query)
                Pair(true, "জি তাপস স্যার, ওয়েব সার্চ করা হচ্ছে।")
            }
            else -> Pair(true, "জি তাপস স্যার, সম্পন্ন হয়েছে।")
        }
    }

    private fun getDisplayName(appName: String): String {
        return when (appName.lowercase()) {
            "youtube" -> "YouTube"
            "facebook" -> "Facebook"
            "whatsapp" -> "WhatsApp"
            "maps" -> "Google Maps"
            "chrome" -> "Chrome"
            "gmail" -> "Gmail"
            "camera" -> "ক্যামেরা"
            "settings" -> "সেটিংস"
            "calculator" -> "ক্যালকুলেটর"
            else -> appName
        }
    }

    /**
     * 1. Safe App Opener
     * Attempts to launch YouTube or target app using direct Package Manager Intent.
     */
    fun openApp(appName: String): Boolean {
        val packageMap = mapOf(
            "youtube" to "com.google.android.youtube",
            "facebook" to "com.facebook.katana",
            "whatsapp" to "com.whatsapp",
            "maps" to "com.google.android.apps.maps",
            "gmail" to "com.google.android.gm",
            "chrome" to "com.android.chrome",
            "calculator" to "com.google.android.calculator",
            "camera" to "android.media.action.IMAGE_CAPTURE",
            "settings" to "android.settings.SETTINGS"
        )

        val target = appName.lowercase().trim()
        val pkg = packageMap[target] ?: target

        try {
            if (target == "camera") {
                val intent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return true
            }

            if (target == "settings") {
                val intent = Intent(android.provider.Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return true
            }

            // Direct Package launch intent for YouTube and installed apps
            val launchIntent = context.packageManager.getLaunchIntentForPackage(pkg)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                return true
            }

            // Fallback for YouTube via direct URI intent
            if (target == "youtube") {
                val ytIntent = Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (ytIntent.resolveActivity(context.packageManager) != null) {
                    context.startActivity(ytIntent)
                    return true
                }
            }
        } catch (e: Exception) {
            Toast.makeText(context, "অ্যাপ চালু করতে ত্রুটি: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            return false
        }

        Toast.makeText(context, "$appName ইনস্টল করা নেই", Toast.LENGTH_SHORT).show()
        return false
    }

    /**
     * 2. Safe Phone Calling (Opens dialer with confirmation)
     */
    fun makeSafeCall(phoneNumber: String) {
        val intent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:${Uri.encode(phoneNumber)}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    /**
     * 3. Safe SMS Composer (Never sends silently without user confirmation)
     */
    fun composeSms(recipient: String, message: String) {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:${Uri.encode(recipient)}")
            putExtra("sms_body", message)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    /**
     * 4. Google Maps Navigation Intent
     */
    fun startNavigation(destination: String) {
        val gmmIntentUri = Uri.parse("google.navigation:q=${Uri.encode(destination)}")
        val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri).apply {
            setPackage("com.google.android.apps.maps")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (mapIntent.resolveActivity(context.packageManager) != null) {
            context.startActivity(mapIntent)
        } else {
            // Web fallback
            val webUri = Uri.parse("https://www.google.com/maps/dir/?api=1&destination=${Uri.encode(destination)}")
            val webIntent = Intent(Intent.ACTION_VIEW, webUri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(webIntent)
        }
    }

    /**
     * 5. Device Flashlight Torch Controller
     * Directly controls physical back camera LED flash via Android CameraManager.setTorchMode without camera preview.
     * Selects camera with LENS_FACING_BACK and FLASH_INFO_AVAILABLE == true.
     * Validates runtime CAMERA permission using ContextCompat.checkSelfPermission & ActivityCompat.requestPermissions.
     */
    fun toggleFlashlight(state: String?): Pair<Boolean, String> {
        // 1. Check & Request Runtime Camera Permission
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            if (context is Activity) {
                ActivityCompat.requestPermissions(context, arrayOf(Manifest.permission.CAMERA), 1002)
            }
            val deniedMsg = "তাপস স্যার, ক্যামেরা permission না দেওয়ায় ফ্ল্যাশলাইট চালু করতে পারছি না।"
            Toast.makeText(context, deniedMsg, Toast.LENGTH_SHORT).show()
            return Pair(false, deniedMsg)
        }

        // 2. Check Hardware Flashlight Feature
        if (!context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)) {
            Toast.makeText(context, "এই ডিভাইসে ফ্ল্যাশলাইট হার্ডওয়্যার নেই", Toast.LENGTH_SHORT).show()
            return Pair(false, "তাপস স্যার, এই ডিভাইসে ফ্ল্যাশলাইট হার্ডওয়্যার উপলব্ধ নেই।")
        }

        try {
            // Find back-facing camera with hardware flash unit
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                val characteristics = cameraManager.getCameraCharacteristics(id)
                val hasFlash = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                val isBackFacing = characteristics.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
                hasFlash && isBackFacing
            }

            if (cameraId == null) {
                return Pair(false, "তাপস স্যার, ডিভাইসের পিছনের ক্যামেরা ফ্ল্যাশ (Back Camera Flash) পাওয়া যায়নি।")
            }

            val shouldTurnOn = when (state?.lowercase()) {
                "on" -> true
                "off" -> false
                else -> !isTorchOn
            }

            // Only use CameraManager.setTorchMode - no camera preview used
            cameraManager.setTorchMode(cameraId, shouldTurnOn)
            isTorchOn = shouldTurnOn

            val spokenReply = if (shouldTurnOn) {
                "জি তাপস স্যার, পিছনের ফ্ল্যাশলাইট জ্বালিয়ে দিয়েছি।"
            } else {
                "জি তাপস স্যার, ফ্ল্যাশলাইট নিভিয়ে দিয়েছি।"
            }

            val toastMsg = if (shouldTurnOn) "পিছনের ফ্ল্যাশলাইট চালু হয়েছে" else "ফ্ল্যাশলাইট বন্ধ হয়েছে"
            Toast.makeText(context, toastMsg, Toast.LENGTH_SHORT).show()

            return Pair(true, spokenReply)
        } catch (e: CameraAccessException) {
            val err = "তাপস স্যার, ক্যামেরা অ্যাক্সেস করা সম্ভব হচ্ছে না: ${e.localizedMessage}"
            Toast.makeText(context, err, Toast.LENGTH_SHORT).show()
            return Pair(false, err)
        } catch (e: SecurityException) {
            val err = "তাপস স্যার, ক্যামেরা permission না দেওয়ায় ফ্ল্যাশলাইট চালু করতে পারছি না।"
            Toast.makeText(context, err, Toast.LENGTH_SHORT).show()
            return Pair(false, err)
        } catch (e: Exception) {
            val err = "তাপস স্যার, ফ্ল্যাশলাইট নিয়ন্ত্রণ করতে সমস্যা হয়েছে: ${e.localizedMessage}"
            Toast.makeText(context, err, Toast.LENGTH_SHORT).show()
            return Pair(false, err)
        }
    }

    /**
     * 6. Web Search Intent
     */
    fun searchWeb(query: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    /**
     * 7. Accept Incoming Ringing Phone Call
     * Uses Android TelecomManager.acceptRingingCall() with runtime ANSWER_PHONE_CALLS permission check.
     */
    fun acceptIncomingCall(): Pair<Boolean, String> {
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ANSWER_PHONE_CALLS
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasPermission) {
            val errMsg = "তাপস স্যার, কল রিসিভ করার জন্য ANSWER_PHONE_CALLS পারমিশন প্রয়োজন।"
            Toast.makeText(context, errMsg, Toast.LENGTH_LONG).show()
            return Pair(false, errMsg)
        }

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
                if (telecomManager != null) {
                    telecomManager.acceptRingingCall()
                    val msg = "জি তাপস স্যার, কলটি রিসিভ করা হয়েছে।"
                    Toast.makeText(context, "ইনকামিং কল রিসিভ হয়েছে", Toast.LENGTH_SHORT).show()
                    Pair(true, msg)
                } else {
                    Pair(false, "তাপস স্যার, ডিভাইসের Telecom Service পাওয়া যায়নি।")
                }
            } else {
                Pair(false, "তাপস স্যার, এই অ্যান্ড্রয়েড সংস্করণে অটো কল রিসিভ সমর্থিত নয়।")
            }
        } catch (e: SecurityException) {
            val msg = "তাপস স্যার, সিকিউরিটি পারমিশন না থাকায় কল রিসিভ করা যায়নি।"
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            Pair(false, msg)
        } catch (e: Exception) {
            val msg = "তাপস স্যার, কল রিসিভ করতে সমস্যা হয়েছে: ${e.localizedMessage}"
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            Pair(false, msg)
        }
    }

    /**
     * 8. End or Reject Incoming / Active Phone Call
     * Uses Android TelecomManager.endCall() with runtime ANSWER_PHONE_CALLS permission check.
     */
    fun endOrRejectCall(): Pair<Boolean, String> {
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ANSWER_PHONE_CALLS
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasPermission) {
            val errMsg = "তাপস স্যার, কল কাটার জন্য ANSWER_PHONE_CALLS পারমিশন প্রয়োজন।"
            Toast.makeText(context, errMsg, Toast.LENGTH_LONG).show()
            return Pair(false, errMsg)
        }

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
                val ended = telecomManager?.endCall() ?: false
                if (ended) {
                    val msg = "জি তাপস স্যার, কলটি কেটে দেওয়া হয়েছে।"
                    Toast.makeText(context, "কল কেটে দেওয়া হয়েছে", Toast.LENGTH_SHORT).show()
                    Pair(true, msg)
                } else {
                    Pair(false, "তাপস স্যার, অ্যান্ড্রয়েড সিস্টেম কলটি কাটতে দেয়নি।")
                }
            } else {
                Pair(false, "তাপস স্যার, এই অ্যান্ড্রয়েড সংস্করণে কল রিজেক্ট সমর্থিত নয়।")
            }
        } catch (e: SecurityException) {
            val msg = "তাপস স্যার, সিস্টেম সিকিউরিটি বিধিনিষেধের কারণে কলটি কাটা সম্ভব হয়নি।"
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            Pair(false, msg)
        } catch (e: Exception) {
            val msg = "তাপস স্যার, কল কাটতে সমস্যা হয়েছে: ${e.localizedMessage}"
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            Pair(false, msg)
        }
    }
}