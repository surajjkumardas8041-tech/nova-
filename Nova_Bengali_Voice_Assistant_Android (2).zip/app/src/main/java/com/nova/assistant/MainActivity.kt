package com.nova.assistant

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nova.assistant.intents.IntentActionHandler
import com.nova.assistant.service.NovaForegroundVoiceService
import com.nova.assistant.speech.SpeechRecognizerManager
import com.nova.assistant.speech.TextToSpeechManager
import com.nova.assistant.ui.theme.NovaAssistantTheme
import com.nova.assistant.ui.viewmodel.AssistantViewModel

class MainActivity : ComponentActivity() {

    private lateinit var speechManager: SpeechRecognizerManager
    private lateinit var ttsManager: TextToSpeechManager
    private lateinit var intentHandler: IntentActionHandler

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val recordAudioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false
        if (recordAudioGranted) {
            Toast.makeText(this, "মাইক্রোফোন অনুমতি সক্রিয় হয়েছে", Toast.LENGTH_SHORT).show()
            startAlwaysReadyForegroundService()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize Native Managers
        speechManager = SpeechRecognizerManager(this)
        ttsManager = TextToSpeechManager(this)
        intentHandler = IntentActionHandler(this)

        // Request core permissions on startup (including Android 13+ POST_NOTIFICATIONS, 14+ MIC, and Phone Call Controls)
        val permissionsList = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.READ_PHONE_STATE
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            permissionsList.add(Manifest.permission.ANSWER_PHONE_CALLS)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionsList.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        requestPermissionLauncher.launch(permissionsList.toTypedArray())

        // Start Always-Ready Standby Voice Assistant Service
        startAlwaysReadyForegroundService()

        setContent {
            NovaAssistantTheme {
                val viewModel: AssistantViewModel = viewModel()
                NovaMainScreen(
                    viewModel = viewModel,
                    onStartListening = { lang ->
                        speechManager.startListening(
                            language = lang,
                            onResult = { query ->
                                viewModel.processVoiceQuery(query, lang)
                            },
                            onError = { err ->
                                Toast.makeText(this, err, Toast.LENGTH_SHORT).show()
                            }
                        )
                    },
                    onStopListening = { speechManager.stopListening() },
                    onSpeak = { text, lang -> ttsManager.speak(text, lang) },
                    intentHandler = intentHandler
                )
            }
        }
    }

    private fun startAlwaysReadyForegroundService() {
        try {
            val serviceIntent = Intent(this, NovaForegroundVoiceService::class.java).apply {
                action = NovaForegroundVoiceService.ACTION_START_STANDBY
            }
            ContextCompat.startForegroundService(this, serviceIntent)
        } catch (e: Exception) {
            // Handled safely
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        speechManager.destroy()
        ttsManager.shutdown()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NovaMainScreen(
    viewModel: AssistantViewModel,
    onStartListening: (String) -> Unit,
    onStopListening: () -> Unit,
    onSpeak: (String, String) -> Unit,
    intentHandler: IntentActionHandler
) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedTab by remember { mutableStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "নভা (Nova)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        AssistChip(
                            onClick = { viewModel.toggleLanguage() },
                            label = { Text(if (uiState.language == "bn") "বাংলা" else "English") }
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { /* Open Settings */ }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("মূল স্ক্রিন") },
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.History, contentDescription = "History") },
                    label = { Text("ইতিহাস") },
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Note, contentDescription = "Notes") },
                    label = { Text("নোট ও স্মরণ") },
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 }
                )
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (uiState.isListening) {
                        onStopListening()
                        viewModel.setListening(false)
                    } else {
                        viewModel.setListening(true)
                        onStartListening(uiState.language)
                    }
                },
                containerColor = if (uiState.isListening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                shape = CircleShape,
                modifier = Modifier.size(68.dp)
            ) {
                Icon(
                    imageVector = if (uiState.isListening) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = "Voice Activation",
                    tint = Color.White,
                    modifier = Modifier.size(32.dp)
                )
            }
        },
        floatingActionButtonPosition = FabPosition.Center
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (selectedTab) {
                0 -> NovaHomeView(
                    uiState = uiState,
                    onQuickCommand = { cmd ->
                        viewModel.processVoiceQuery(cmd, uiState.language)
                    }
                )
                1 -> NovaHistoryView(history = uiState.history)
                2 -> NovaNotesView(notes = uiState.notes, reminders = uiState.reminders)
            }

            // Voice Assistant Active Bottom Sheet Overlay
            AnimatedVisibility(
                visible = uiState.isAssistantActive,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                modifier = Modifier.align(Alignment.BottomCenter)
            ) {
                NovaAssistantOverlaySheet(
                    uiState = uiState,
                    onDismiss = { viewModel.dismissAssistant() },
                    onExecuteIntent = { intent ->
                        intentHandler.executeIntent(intent)
                    }
                )
            }
        }
    }
}

@Composable
fun NovaHomeView(
    uiState: com.nova.assistant.ui.viewmodel.AssistantUiState,
    onQuickCommand: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Bengali Greeting Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "শুভ দিন! আমি কীভাবে সাহায্য করতে পারি?",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "বলুন: 'নভা' বা মাইক্রোফোন বাটনে চাপ দিন",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Quick Spoken Command Chips
        Text(
            text = "জনপ্রিয় ভয়েস কমান্ডসমূহ",
            fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.Start)
        )
        Spacer(modifier = Modifier.height(10.dp))

        val sampleCommands = listOf(
            "ইউটিউব খোল",
            "ফ্ল্যাশলাইট জ্বালাও",
            "ধানমন্ডির ম্যাপ দেখাও",
            "মাকে ফোন দাও",
            "আজকের আবহাওয়া কেমন?",
            "একটি জরুরি নোট লেখো"
        )

        sampleCommands.forEach { cmd ->
            OutlinedButton(
                onClick = { onQuickCommand(cmd) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.GraphicEq, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = ""$cmd"")
            }
        }
    }
}

@Composable
fun NovaHistoryView(history: List<com.nova.assistant.data.model.CommandHistoryItem>) {
    // List of past voice commands and assistant replies
    Text(
        text = "কমান্ড ইতিহাস",
        modifier = Modifier.padding(16.dp),
        fontWeight = FontWeight.Bold
    )
}

@Composable
fun NovaNotesView(
    notes: List<com.nova.assistant.data.model.NoteItem>,
    reminders: List<com.nova.assistant.data.model.ReminderItem>
) {
    Text(
        text = "সংরক্ষিত নোট ও স্মরণিকা",
        modifier = Modifier.padding(16.dp),
        fontWeight = FontWeight.Bold
    )
}

@Composable
fun NovaAssistantOverlaySheet(
    uiState: com.nova.assistant.ui.viewmodel.AssistantUiState,
    onDismiss: () -> Unit,
    onExecuteIntent: (com.nova.assistant.data.model.AssistantIntentAction) -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)),
        color = MaterialTheme.colorScheme.surfaceColorAtElevation(8.dp),
        tonalElevation = 8.dp
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = uiState.recognizedSpeech.ifEmpty { "শুনছি... কথা বলুন" },
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = uiState.assistantSpokenResponse,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = onDismiss) {
                Text("সম্পন্ন")
            }
        }
    }
}