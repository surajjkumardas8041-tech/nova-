package com.nova.assistant.service

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.nova.assistant.MainActivity
import com.nova.assistant.R
import com.nova.assistant.data.local.PreferencesManager
import com.nova.assistant.data.model.AssistantIntentAction
import com.nova.assistant.intents.IntentActionHandler
import com.nova.assistant.speech.SpeechRecognizerManager
import com.nova.assistant.speech.TextToSpeechManager
import com.nova.assistant.util.BatteryOptimizationHelper

/**
 * NovaForegroundVoiceService
 * Android 14+ (API 34+) compliant Foreground Microphone Voice Assistant Service.
 * - Enforces RECORD_AUDIO permission: Never claims Active unless permission is granted and service is running.
 * - Starts at Phone Boot / User Activation in low-power standby mode.
 * - Listens for wake phrases: "Nova", "নভা", "নোভা", "Hey Nova".
 * - Upon wake word detection: Immediately starts the existing SpeechRecognizer to listen for user's Bengali or English command WITHOUT requiring any button tap.
 * - Real Incoming-Call Voice Control: announces "তাপস স্যার, একটি কল এসেছে।" and listens for "রিসিভ করো" / "কল কেটে দাও".
 * - Privacy: Zero continuous disk audio recording and zero upload of conversation streams.
 * - Broadcasts real-time diagnostic status so UI and diagnostics accurately know whether service is actually listening in standby.
 */
class NovaForegroundVoiceService : Service() {

    companion object {
        const val TAG = "NovaForegroundService"
        const val ACTION_START_STANDBY = "com.nova.assistant.ACTION_START_STANDBY"
        const val ACTION_STOP_SERVICE = "com.nova.assistant.ACTION_STOP_SERVICE"
        const val ACTION_INCOMING_CALL = "com.nova.assistant.ACTION_INCOMING_CALL"
        const val EXTRA_INCOMING_NUMBER = "extra_incoming_number"

        // Real-Time Diagnostic Broadcast
        const val ACTION_WAKE_WORD_STATUS = "com.nova.assistant.ACTION_WAKE_WORD_STATUS"
        const val EXTRA_STATUS = "extra_status"
        const val EXTRA_MESSAGE = "extra_message"
        const val EXTRA_TIMESTAMP = "extra_timestamp"

        const val STATUS_STANDBY_LISTENING = "STANDBY_LISTENING"
        const val STATUS_WAKE_WORD_DETECTED = "WAKE_WORD_DETECTED"
        const val STATUS_LISTENING_COMMAND = "LISTENING_COMMAND"
        const val STATUS_PROCESSING = "PROCESSING"
        const val STATUS_SPEAKING = "SPEAKING"
        const val STATUS_STOPPED = "STOPPED"
        const val STATUS_PERMISSION_REQUIRED = "PERMISSION_REQUIRED"
        const val STATUS_BATTERY_RESTRICTED = "BATTERY_RESTRICTED"

        const val CHANNEL_ID = "nova_voice_assistant_channel"
        const val NOTIFICATION_ID = 2024

        @Volatile
        var isServiceActive: Boolean = false
            private set

        @Volatile
        var currentDiagnosticStatus: String = STATUS_STOPPED
            private set
    }

    private var speechRecognizerManager: SpeechRecognizerManager? = null
    private var textToSpeechManager: TextToSpeechManager? = null
    private var intentActionHandler: IntentActionHandler? = null

    private var isStandby = false
    private var isExecutingCommand = false

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "Nova Foreground Voice Service Created")
        createNotificationChannel()

        speechRecognizerManager = SpeechRecognizerManager(this)
        textToSpeechManager = TextToSpeechManager(this)
        intentActionHandler = IntentActionHandler(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START_STANDBY

        when (action) {
            ACTION_STOP_SERVICE -> {
                stopStandby()
                broadcastDiagnosticStatus(STATUS_STOPPED, "স্ট্যান্ডবাই ওয়েক ওয়ার্ড বন্ধ রয়েছে")
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START_STANDBY -> {
                val isEnabled = PreferencesManager.isWakeWordEnabled(this)
                if (!isEnabled) {
                    Log.i(TAG, "Wake word is disabled in settings; stopping standby service.")
                    stopStandby()
                    broadcastDiagnosticStatus(STATUS_STOPPED, "স্ট্যান্ডবাই ওয়েক ওয়ার্ড বন্ধ রয়েছে")
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                    return START_NOT_STICKY
                }

                val hasMicPermission = ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED

                if (!hasMicPermission) {
                    Log.e(TAG, "Cannot start Wake Word: RECORD_AUDIO permission missing!")
                    isServiceActive = false
                    broadcastDiagnosticStatus(
                        STATUS_PERMISSION_REQUIRED,
                        "মাইক্রোফোন অনুমতি (RECORD_AUDIO) অনুপস্থিত। ওয়েক ওয়ার্ড নিষ্ক্রিয়।"
                    )
                    stopSelf()
                    return START_NOT_STICKY
                }

                startForegroundServiceWithNotification()
                startStandbyWakeWordListening()
            }
            ACTION_INCOMING_CALL -> {
                val number = intent?.getStringExtra(EXTRA_INCOMING_NUMBER) ?: ""
                handleIncomingCallEvent(number)
            }
        }

        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Nova Voice Assistant",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Nova Assistant সর্বদা প্রস্তুত • ব্যাকগ্রাউন্ড স্ট্যান্ডবাই মোড"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun startForegroundServiceWithNotification() {
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            notificationIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val isBatteryProtected = BatteryOptimizationHelper.isIgnoringBatteryOptimizations(this)
        val statusSubtitle = if (isBatteryProtected) {
            "বলুন 'Nova' বা 'নভা' • স্ট্যান্ডবাই শুনছে"
        } else {
            "বলুন 'Nova' • ব্যাটারি অপটিমাইজেশন বন্ধ করার সুপারিশ"
        }

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("নোভা (Nova) সর্বদা প্রস্তুত")
            .setContentText(statusSubtitle)
            .setSmallIcon(R.drawable.ic_nova_tile)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

        // Android 14+ (API 34+) FOREGROUND_SERVICE_TYPE_MICROPHONE specification
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    /**
     * Start Low-Power Standby Wake Word Listener
     * Privacy: Does NOT record audio to storage; triggers command recognizer only on wake word.
     */
    private fun startStandbyWakeWordListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Log.w(TAG, "Cannot start standby: RECORD_AUDIO permission missing")
            broadcastDiagnosticStatus(STATUS_PERMISSION_REQUIRED, "মাইক্রোফোন অনুমতি প্রয়োজন")
            isServiceActive = false
            return
        }

        isStandby = true
        isServiceActive = true
        broadcastDiagnosticStatus(STATUS_STANDBY_LISTENING, "স্ট্যান্ডবাই সক্রিয় • 'Nova' বা 'নভা' শুনছে")
        Log.i(TAG, "Nova is now in low-power Standby state listening for Wake Word 'Nova' / 'নভা'...")

        speechRecognizerManager?.startListening(
            language = "bn",
            onResult = { transcript ->
                handleIncomingSpokenUtterance(transcript)
            },
            onError = { _ ->
                // Resume standby seamlessly if silence timeout
                if (isStandby && !isExecutingCommand) {
                    android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                        if (isStandby && !isExecutingCommand) {
                            startStandbyWakeWordListening()
                        }
                    }, 400)
                }
            }
        )
    }

    /**
     * Handles spoken text from user in standby.
     * When wake word detected, immediately triggers SpeechRecognizer for command without requiring button tap.
     */
    private fun handleIncomingSpokenUtterance(rawText: String) {
        val text = rawText.trim()
        val lower = text.lowercase()

        // Detect Wake Word phrases ("Nova", "নভা", "নোভা", "Hey Nova", "Hello Nova")
        val hasWakeWord = lower.contains("নোভা") || lower.contains("নভা") || lower.contains("nova") || lower.contains("hey nova")

        if (hasWakeWord || isStandby) {
            // Strip wake word prefix if user spoke compound phrase in one breath
            val cleanedQuery = text
                .replace("(?i)hey nova".toRegex(), "")
                .replace("(?i)hello nova".toRegex(), "")
                .replace("(?i)nova".toRegex(), "")
                .replace("নোভা", "")
                .replace("নভা", "")
                .trim()

            if (cleanedQuery.isBlank()) {
                // User just said "Nova" -> Acknowledge and IMMEDIATELY start listening for their command WITHOUT button tap
                isExecutingCommand = true
                broadcastDiagnosticStatus(STATUS_WAKE_WORD_DETECTED, "ওয়েক ওয়ার্ড সনাক্ত হয়েছে! কমান্ড শুনছি...")
                val promptMsg = "জি তাপস স্যার, বলুন আমি শুনছি।"
                textToSpeechManager?.speak(promptMsg, "bn")

                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                    listenForFinalCommand()
                }, 1400)
            } else {
                // User said "Nova [Command]" in one breath -> Execute immediately
                broadcastDiagnosticStatus(STATUS_WAKE_WORD_DETECTED, "ওয়েক ওয়ার্ড ও সরাসরি কমান্ড প্রাপ্তি")
                executeCommand(cleanedQuery)
            }
        }
    }

    /**
     * Zero-Click command listener after Wake Word detection
     */
    private fun listenForFinalCommand() {
        isExecutingCommand = true
        broadcastDiagnosticStatus(STATUS_LISTENING_COMMAND, "কমান্ড শুনছি (বাংলা বা ইংরেজি)...")

        speechRecognizerManager?.startListening(
            language = "bn",
            onResult = { commandText ->
                executeCommand(commandText)
            },
            onError = { error ->
                isExecutingCommand = false
                val errMsg = "তাপস স্যার, $error"
                textToSpeechManager?.speak(errMsg, "bn")
                startStandbyWakeWordListening()
            }
        )
    }

    /**
     * Handles Incoming Call Announcement and auto-listens for user voice response ("রিসিভ করো" / "কেটে দাও").
     */
    private fun handleIncomingCallEvent(incomingNumber: String) {
        isExecutingCommand = true
        speechRecognizerManager?.stopListening()

        val announcement = "তাপস স্যার, একটি কল এসেছে।"
        Log.i(TAG, "Announcing incoming call to Tapas Sir: $announcement")
        textToSpeechManager?.speak(announcement, "bn")

        // Immediately start hands-free listening for user's voice instruction without requiring tap
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            broadcastDiagnosticStatus(STATUS_LISTENING_COMMAND, "কল কন্ট্রোল কমান্ড শুনছি...")
            speechRecognizerManager?.startListening(
                language = "bn",
                onResult = { voiceCommand ->
                    executeCommand(voiceCommand)
                },
                onError = { _ ->
                    isExecutingCommand = false
                    if (isStandby) {
                        startStandbyWakeWordListening()
                    }
                }
            )
        }, 1800)
    }

    /**
     * Execute parsed intent action through IntentActionHandler or query AI Brain asynchronously via Coroutines
     */
    private val serviceScope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main + kotlinx.coroutines.SupervisorJob())
    private var currentCommandJob: kotlinx.coroutines.Job? = null

    private fun executeCommand(command: String) {
        // Cancel any pending AI query immediately when a new command begins
        currentCommandJob?.cancel()

        isExecutingCommand = true
        broadcastDiagnosticStatus(STATUS_PROCESSING, "কমান্ড প্রসেসিং: '$command'")
        Log.i(TAG, "Executing command for Tapas Sir: $command")

        val action = parseIntentAction(command)

        if (action != null) {
            val (success, outcomeMsg) = intentActionHandler?.executeIntent(action) ?: Pair(false, "তাপস স্যার, কমান্ড সম্পন্ন করা যায়নি।")
            speakAndFinishCommand(outcomeMsg)
        } else {
            // Asynchronous AI Brain Query via Coroutines (Dispatchers.IO) with timeout and fallback
            currentCommandJob = serviceScope.launch {
                val aiResponse = withContext(kotlinx.coroutines.Dispatchers.IO) {
                    com.nova.assistant.data.api.NovaAiBrainClient.askAiBrain(command, "bn")
                }
                speakAndFinishCommand(aiResponse)
            }
        }
    }

    private fun speakAndFinishCommand(responseText: String) {
        // Speak aloud result addressing Tapas Sir
        broadcastDiagnosticStatus(STATUS_SPEAKING, "উত্তর উচ্চারণ করা হচ্ছে...")
        textToSpeechManager?.speak(responseText, "bn")

        // Return to low-power standby mode
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            isExecutingCommand = false
            if (isStandby) {
                startStandbyWakeWordListening()
            }
        }, 2800)
    }

    private fun parseIntentAction(query: String): AssistantIntentAction? {
        val lower = query.lowercase().trim()

        return when {
            // Real Incoming Call Voice Actions (Accept / Reject)
            lower.contains("রিসিভ") || lower.contains("receive") || lower.contains("accept") || lower.contains("ধরো") || lower.contains("ধর") || lower.contains("কল ধর") -> {
                AssistantIntentAction("ACCEPT_CALL", emptyMap())
            }
            lower.contains("কেটে দাও") || lower.contains("কাটো") || lower.contains("বাতিল") || lower.contains("রিজেক্ট") || lower.contains("reject") || lower.contains("end call") || lower.contains("ডিসকানেক্ট") || lower.contains("কাটুন") -> {
                AssistantIntentAction("END_CALL", emptyMap())
            }
            lower.contains("ইউটিউব") || lower.contains("youtube") || lower.contains("yt") -> {
                AssistantIntentAction("OPEN_APP", mapOf("appName" to "youtube"))
            }
            lower.contains("ফেসবুক") || lower.contains("facebook") || lower.contains("fb") -> {
                AssistantIntentAction("OPEN_APP", mapOf("appName" to "facebook"))
            }
            lower.contains("হোয়াটসঅ্যাপ") || lower.contains("whatsapp") -> {
                AssistantIntentAction("OPEN_APP", mapOf("appName" to "whatsapp"))
            }
            lower.contains("ক্রোম") || lower.contains("chrome") || lower.contains("ব্রাউজার") -> {
                AssistantIntentAction("OPEN_APP", mapOf("appName" to "chrome"))
            }
            lower.contains("ক্যামেরা") || lower.contains("camera") -> {
                AssistantIntentAction("OPEN_APP", mapOf("appName" to "camera"))
            }
            lower.contains("সেটিংস") || lower.contains("settings") -> {
                AssistantIntentAction("OPEN_APP", mapOf("appName" to "settings"))
            }
            lower.contains("টর্চ") || lower.contains("ফ্ল্যাশ") || lower.contains("flashlight") || lower.contains("torch") -> {
                val isTurnOff = lower.contains("বন্ধ") || lower.contains("নিভ") || lower.contains("নেভ") || lower.contains("off")
                val state = if (isTurnOff) "off" else "on"
                AssistantIntentAction("TOGGLE_FLASHLIGHT", mapOf("state" to state))
            }
            lower.contains("ম্যাপ") || lower.contains("লোকেশন") || lower.contains("maps") || lower.contains("রাস্তা") -> {
                val destination = query.replace("ম্যাপ", "").replace("maps", "").replace("খোল", "").replace("দেখা", "").trim()
                val target = if (destination.isEmpty()) "Dhaka" else destination
                AssistantIntentAction("NAVIGATE_MAPS", mapOf("destination" to target))
            }
            lower.contains("কল") || lower.contains("ফোন") || lower.contains("call") -> {
                AssistantIntentAction("CALL_PHONE", mapOf("phoneNumber" to ""))
            }
            else -> null
        }
    }

    private fun getSmartReplyForQuery(query: String): String {
        val lower = query.lowercase().trim()
        return when {
            lower.contains("আবহাওয়া") || lower.contains("weather") -> "তাপস স্যার, আজকের আবহাওয়া চমৎকার ও পরিষ্কার।"
            lower.contains("কেমন আছো") || lower.contains("how are you") -> "জি তাপস স্যার, আমি ভালো আছি। আপনার জন্য কী করতে পারি?"
            lower.contains("সময়") || lower.contains("time") -> "জি তাপস স্যার, এখনকার সময় ডিভাইস ঘড়িতে প্রদর্শিত হচ্ছে।"
            else -> "জি তাপস স্যার, আমি আপনার নির্দেশ পেয়েছি।"
        }
    }

    private fun broadcastDiagnosticStatus(status: String, message: String) {
        currentDiagnosticStatus = status
        val intent = Intent(ACTION_WAKE_WORD_STATUS).apply {
            putExtra(EXTRA_STATUS, status)
            putExtra(EXTRA_MESSAGE, message)
            putExtra(EXTRA_TIMESTAMP, System.currentTimeMillis())
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }

    private fun stopStandby() {
        isStandby = false
        isServiceActive = false
        speechRecognizerManager?.stopListening()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopStandby()
        broadcastDiagnosticStatus(STATUS_STOPPED, "সার্ভিস সমাপ্ত হয়েছে")
        speechRecognizerManager?.destroy()
        textToSpeechManager?.shutdown()
        Log.i(TAG, "Nova Foreground Voice Service Destroyed")
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
