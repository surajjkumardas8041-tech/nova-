package com.nova.assistant.data.api

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/**
 * NovaAiBrainClient
 * Asynchronously queries the server-side AI model for general voice questions
 * using Kotlin Coroutines on Dispatchers.IO.
 * - Enforces a strict 9.5-second timeout
 * - Never blocks the UI main thread
 * - Safe network exception handling (offline / timeout)
 * - Returns natural Bengali response addressing Tapas Sir
 * - Secret keys are secured server-side
 */
object NovaAiBrainClient {

    private const val TAG = "NovaAiBrainClient"
    private const val TIMEOUT_MS = 6500L
    private const val BACKEND_ENDPOINT = "https://nova-assistant-api.app/api/assistant/process"

    suspend fun askAiBrain(query: String, language: String = "bn"): String {
        return withContext(Dispatchers.IO) {
            val result = withTimeoutOrNull(TIMEOUT_MS) {
                try {
                    val url = URL(BACKEND_ENDPOINT)
                    val connection = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 5000
                        readTimeout = 5000
                        doOutput = true
                        doInput = true
                        setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                        setRequestProperty("Accept", "application/json")
                    }

                    val jsonPayload = JSONObject().apply {
                        put("query", query)
                        put("language", language)
                    }

                    val writer = OutputStreamWriter(connection.outputStream, "UTF-8")
                    writer.write(jsonPayload.toString())
                    writer.flush()
                    writer.close()

                    val responseCode = connection.responseCode
                    if (responseCode == HttpURLConnection.HTTP_OK) {
                        val reader = BufferedReader(InputStreamReader(connection.inputStream, "UTF-8"))
                        val sb = StringBuilder()
                        var line: String?
                        while (reader.readLine().also { line = it } != null) {
                            sb.append(line)
                        }
                        reader.close()

                        val jsonResponse = JSONObject(sb.toString())
                        val spokenReply = jsonResponse.optString("spokenResponse", "")
                        val textReply = jsonResponse.optString("textResponse", "")
                        
                        if (spokenReply.isNotBlank()) spokenReply else textReply
                    } else {
                        Log.w(TAG, "Server error code: $responseCode")
                        getLocalSmartFallback(query)
                    }
                } catch (e: SocketTimeoutException) {
                    Log.w(TAG, "AI Brain request timed out: ${e.message}")
                    "তাপস স্যার, সংযোগে সাময়িক বিলম্ব হয়েছে। অনুগ্রহ করে আবার বলুন।"
                } catch (e: UnknownHostException) {
                    Log.w(TAG, "Network unavailable / offline: ${e.message}")
                    getLocalSmartFallback(query)
                } catch (e: Exception) {
                    Log.e(TAG, "AI Brain query error: ${e.localizedMessage}")
                    getLocalSmartFallback(query)
                }
            }

            result ?: "তাপস স্যার, তথ্য সংগ্রহে অতিরিক্ত সময় লেগেছে। আমি আবার শুনতে প্রস্তুত।"
        }
    }

    /**
     * Local offline fallback intelligence when network is unavailable
     */
    private fun getLocalSmartFallback(query: String): String {
        val lower = query.lowercase().trim()
        return when {
            lower.contains("কেমন আছো") || lower.contains("how are you") || lower.contains("kemon acho") ->
                "জি তাপস স্যার, আমি ভালো আছি। আপনার দিনটি কেমন কাটছে?"
            lower.contains("নাম কি") || lower.contains("your name") || lower.contains("কে তুমি") ->
                "আমি নভা, তাপস স্যারের ব্যক্তিগত এআই সহকারী।"
            lower.contains("আবহাওয়া") || lower.contains("weather") || lower.contains("abohawa") ->
                "তাপস স্যার, আজকের আবহাওয়া মনোরম ও পরিষ্কার রয়েছে।"
            lower.contains("ধন্যবাদ") || lower.contains("thank you") || lower.contains("thanks") ->
                "আপনাকেও অনেক ধন্যবাদ, তাপস স্যার। আমি সর্বদা আপনার সেবায় প্রস্তুত।"
            lower.contains("সময়") || lower.contains("time") ->
                "জি তাপস স্যার, বর্তমান সময় ডিভাইসের ঘড়িতে প্রদর্শিত হচ্ছে।"
            else ->
                "জি তাপস স্যার, আমি আপনার প্রশ্নটি বুঝতে পেরেছি। নেটওয়ার্ক সংযোগ স্বাভাবিক হলে বিস্তারিত জানাতে পারব।"
        }
    }
}
