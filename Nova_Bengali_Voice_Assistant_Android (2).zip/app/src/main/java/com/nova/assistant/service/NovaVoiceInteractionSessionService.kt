package com.nova.assistant.service

import android.content.Context
import android.os.Bundle
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import com.nova.assistant.R
import com.nova.assistant.data.model.AssistantIntentAction
import com.nova.assistant.intents.IntentActionHandler
import com.nova.assistant.speech.SpeechRecognizerManager
import com.nova.assistant.speech.TextToSpeechManager

class NovaVoiceInteractionSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession {
        return NovaVoiceInteractionSession(this)
    }
}

class NovaVoiceInteractionSession(context: Context) : VoiceInteractionSession(context) {

    private var speechManager: SpeechRecognizerManager? = null
    private var ttsManager: TextToSpeechManager? = null
    private var intentHandler: IntentActionHandler? = null
    private var promptTextView: TextView? = null
    private var statusTextView: TextView? = null

    override fun onCreate() {
        super.onCreate()
        speechManager = SpeechRecognizerManager(context)
        ttsManager = TextToSpeechManager(context)
        intentHandler = IntentActionHandler(context)
    }

    override fun onCreateContentView(): View {
        val inflater = LayoutInflater.from(context)
        val view = inflater.inflate(R.layout.assistant_session_overlay, null)
        promptTextView = view.findViewById(R.id.tv_assistant_speech)
        statusTextView = view.findViewById(R.id.tv_assistant_status)
        return view
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        promptTextView?.text = "শুনছি তাপস স্যার… বলুন"
        statusTextView?.text = "Listening..."
        
        // Auto start listening on Assistant Invocation
        speechManager?.startListening(
            language = "bn",
            onResult = { transcript ->
                promptTextView?.text = transcript
                statusTextView?.text = "Processing..."
                
                // Parse intent action from voice query
                val action = parseIntentAction(transcript)
                
                val responseMsg = if (action != null) {
                    val (success, outcomeMsg) = intentHandler?.executeIntent(action) ?: Pair(false, "ত্রুটি ঘটেছে")
                    outcomeMsg
                } else {
                    getGeneralVoiceResponse(transcript)
                }
                
                // Speak out the spoken response addressing Tapas Sir
                promptTextView?.text = responseMsg
                statusTextView?.text = "Speaking..."
                ttsManager?.speak(responseMsg, "bn")
            },
            onError = { error ->
                val errorMsg = "তাপস স্যার, ${error}"
                promptTextView?.text = errorMsg
                statusTextView?.text = "Idle"
                ttsManager?.speak(errorMsg, "bn")
            }
        )
    }

    private fun parseIntentAction(query: String): AssistantIntentAction? {
        val lower = query.lowercase().trim()
        
        return when {
            lower.contains("ইউটিউব") || lower.contains("youtube") || lower.contains("yt") -> {
                AssistantIntentAction("OPEN_APP", mapOf("appName" to "youtube"))
            }
            lower.contains("ফেসবুক") || lower.contains("facebook") || lower.contains("fb") -> {
                AssistantIntentAction("OPEN_APP", mapOf("appName" to "facebook"))
            }
            lower.contains("হোয়াটসঅ্যাপ") || lower.contains("whatsapp") -> {
                AssistantIntentAction("OPEN_APP", mapOf("appName" to "whatsapp"))
            }
            lower.contains("ক্রোম") || lower.contains("chrome") || lower.contains("ব্রাউজার") -> {
                AssistantIntentAction("OPEN_APP", mapOf("appName" to "chrome"))
            }
            lower.contains("ক্যামেরা") || lower.contains("camera") || lower.contains("ছবি তোল") -> {
                AssistantIntentAction("OPEN_APP", mapOf("appName" to "camera"))
            }
            lower.contains("সেটিংস") || lower.contains("settings") -> {
                AssistantIntentAction("OPEN_APP", mapOf("appName" to "settings"))
            }
            lower.contains("টর্চ") || lower.contains("ফ্ল্যাশ") || lower.contains("flashlight") || lower.contains("torch") -> {
                val isTurnOff = lower.contains("বন্ধ") || lower.contains("নিভ") || lower.contains("নেভ") || lower.contains("off")
                val state = if (isTurnOff) "off" else "on"
                AssistantIntentAction("TOGGLE_FLASHLIGHT", mapOf("state" to state))
            }
            lower.contains("ম্যাপ") || lower.contains("লোকেশন") || lower.contains("ম্যাপস") || lower.contains("maps") || lower.contains("রাস্তা") -> {
                val destination = query.replace("ম্যাপ", "").replace("maps", "").replace("খোল", "").replace("দেখা", "").trim()
                val target = if (destination.isEmpty()) "Dhaka" else destination
                AssistantIntentAction("NAVIGATE_MAPS", mapOf("destination" to target))
            }
            lower.contains("কল") || lower.contains("ফোন") || lower.contains("call") -> {
                AssistantIntentAction("CALL_PHONE", mapOf("phoneNumber" to ""))
            }
            else -> null
        }
    }

    private fun getGeneralVoiceResponse(query: String): String {
        val lower = query.lowercase().trim()
        return if (lower.contains("আবহাওয়া") || lower.contains("weather")) {
            "তাপস স্যার, আজকের আবহাওয়া মনোরম ও পরিষ্কার রয়েছে।"
        } else {
            "জি তাপস স্যার, আমি আপনার নির্দেশ পেয়েছি।"
        }
    }

    override fun onHide() {
        super.onHide()
        speechManager?.stopListening()
        ttsManager?.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        speechManager?.destroy()
        ttsManager?.shutdown()
    }
}