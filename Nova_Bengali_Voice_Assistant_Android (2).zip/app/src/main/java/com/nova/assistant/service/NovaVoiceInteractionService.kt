package com.nova.assistant.service

import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.util.Log

/**
 * Nova Voice Interaction Service
 * Provides Android System Assistant integration (e.g. Long-press home, power button assistant trigger,
 * Corner swipe gesture on Android 10-14+, and Always-on Assistant Hotword invocation).
 */
class NovaVoiceInteractionService : VoiceInteractionService() {

    companion object {
        private const val TAG = "NovaVoiceService"
        
        fun isActive(service: VoiceInteractionService): Boolean {
            return VoiceInteractionService.isActiveService(service, service.componentName)
        }
    }

    override fun onReady() {
        super.onReady()
        Log.i(TAG, "Nova Voice Interaction Service is READY as Android Default Digital Assistant")
        // Ready for system assistant callbacks and hotword listeners
    }

    override fun onShutdown() {
        super.onShutdown()
        Log.i(TAG, "Nova Voice Interaction Service shutdown")
    }
}